﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guichet
{
    abstract class CompteClient
    {
        protected string numerocompte;
        public CompteClient()
        {
           
        }
    }
}
