﻿using System;
using ATM;
using Guichet;

namespace ProjetGuichet
{
    public class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();

            Console.WriteLine("\tSelect votre Guichet");
            Console.WriteLine("\t1- Guichet-Abdel");
            Console.WriteLine("\t2- Guichet-Yvonne");
            Console.WriteLine("\t3- Quitter le service.");

            int choix = int.Parse(Console.ReadLine());

            switch (choix)
            {
                case 1:
                    MainMenu mainMenu = new MainMenu();
                    mainMenu.StartMain();
                    break;

                case 2:
                    Controller controller = new Controller();
                    controller.StartMain();
                    break;

                case 3:
                    Console.WriteLine("Merci d'utiliser notre service. Au revoir.");
                    break;
            }
            
        }
    }
}
